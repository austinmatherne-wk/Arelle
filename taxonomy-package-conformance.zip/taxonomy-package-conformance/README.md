# Taxonomy Package Conformance Suite

This package provides a set a tests for checking the conformance of an XBRL
Taxonomy Package processor.

## Test suite structure

The suite contains an index file (`index.xml`) that contains multiple
`<variations>`.  An example variation is shown below:

```xml
  <variation id="V-002-invalid-multiple-rewrite-uris-for-start-string" name="V-002-invalid-multiple-rewrite-uris-for-start-string">
    <description>Catalog file contains multiple rewrite URIs for the same start string</description>
    <data>
      <taxonomyPackage readMeFirst="true">V-002-invalid-multiple-rewrite-uris-for-start-string.zip</taxonomyPackage>
    </data>
    <result>
      <error>tpe:multipleRewriteURIsForStartString</error>
    </result>
  </variation>

```

Each variation has:

* an ID which is unique within the testcase
* a single input file, specified by the content of `variation/data/taxonomyPackage`.  The `readMeFirst` attribute has no meaning in this suite.
* a `<result>` element specifying the expected output of the variation, as
  described below.

## Expected results

The `<result>` element will contain one of the following:

* No elements.  The variation is a pass case, and processors must not raise any errors.
* One or more `<error>` elements, each containing an error code.  The variation
  is a fail case, and a processor must raise at least one of the specified
  error codes.  Processors may raise additional errors.

