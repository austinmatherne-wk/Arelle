# Open Information Model Conformance Suite

This directory contains conformance suites for the OIM specifications.

## Available suites

The available suites are:

* 100-json-conformant-processor - base suite for xBRL-JSON conformant processors.
* 200-json-validating-conformant-processor - additional tests for xBRL-JSON
  validating conformant processors.
* 300-csv-conformant-processor - suite for xBRL-CSV conformant processors.
* 400-csv-validating-conformant-processor - additional tests for xBRL-CSV
  validating conformant processors.
* 600-xml - suite for testing transformation of xBRL-XML documents.

## Test suite structure

Each directory contains an `index.xml` file containing a `<testcase>` element
with multiple `<variations>`.  An example variation is shown below:

```xml
<variation id="V-05" name="A simple instance with missing namespaces">
  <description>
    Simple instance missing the namespaces
  </description>
  <data>
    <instance readMeFirst="true">helloWorld-missing-prefixes-invalid.json</instance>
  </data>
  <result>
    <error>oimce:unboundPrefix</error>
  </result>
</variation>
```

Each variation has:

* an ID which is unique within the testcase
* a single input file, specified by the content of `variation/data/instance`.  The `readMeFirst` attribute has no meaning in these suites.
* a `<result>` element specifying the expected output of the variation, as
  described below.

## Expected results

The `<result>` element will contain one of the following:

* No elements.  The variation is a pass case, and a processor must raise no errors.
* One or more `<error>` elements, each containing an error code.  The variation
  is a fail case, and a processor must raise at least one of the specified
  error codes.  Processors may raise additional, unlisted errors.

Multiple error codes are provided where the error raised can reasonably depend
on the order in which a processor applies validation, although both the
specification and the conformance suite tests try to avoid this situation.

## Transformation outputs

At present, the suite tests only expected validation results.  This is expected
to change in future.  It is expected that processors will be expected to
produce xBRL-JSON instance documents which will be compared for OIM equivalence
with control files, although the exact process for this has not been defined.

## "invalidJSON" errors

xBRL-JSON and xBRL-CSV require `xbrlje:invalidJSON` and `xbrlce:invalidJSON`
(respectively) to be raised if the document being loaded is not a valid JSON
file.  This creates a problem for processors that support both specifications
and determine document type from the `documentType` property.  It is
recommended that processors implement an option to specify the expected
document type when running the conformance suites, so that the relevant error
can be raised.  For the purposes of XBRL Software Certification testing, these
errors will be treated as equivalent.

See https://gitlab.xbrl.org/oim/oim/-/issues/549

## Table Constraints generated tests

The Table Constraints suites include generated test artifacts.  The durable
source files live in `tests/src/`, the generator scripts live in
`tests/scripts/generators/`, and committed generated outputs live in
`tests/generated/`.

Treat `tests/src/` and `tests/scripts/generators/` as the source of truth.
Files under `tests/generated/` are regenerable artifacts and should not be
hand-edited.  To rebuild `tests/generated/` from scratch, run:

```sh
python3 tests/scripts/generators/regenerate.py
```

This wipes `tests/generated/` and rebuilds it.  To verify that the committed
generated artifacts still match what the generators produce, run:

```sh
python3 tests/scripts/generators/regenerate.py --check
```

which regenerates into a temp directory and diffs against the committed tree.

Each individual generator can also be run directly (e.g.
`python3 tests/scripts/generators/generate_consistency_tests.py`); it will
wipe and rewrite just its own suite directory.

The generated Table Constraints suites currently include:

* `generated/applicability/` - facet applicability by datatype.
* `generated/consistency/` - inter-facet consistency checks.
* `generated/valid-restriction/` - XML Schema valid-restriction checks against
  built-in base type facets.
* `generated/facets-with-invalid-values/` - invalid and valid facet-value
  lexical checks driven by the datatype validity catalogue.

`tests/src/inputs.json` self-validates the generator input tables, using
xBRL-CSV plus Table Constraints to enforce per-column value constraints,
unique keys, and reference keys between the CSVs (e.g. every
`datatype-validity.csv` row's `type` must appear in `datatypes.csv` and
its `(value_id, lexical)` pair must appear in `values.csv`).

### XML Schema interpretation notes

The Table Constraints specification maps XML Schema facet constraints to
`tcme:illegalConstraint`.  The local XML Schema 1.0 Part 2 copy in `ref/` is
the reference used for these tests.

Two XML Schema 1.0 boundary cases are intentionally captured in the generated
tests:

* `minExclusive == maxExclusive` is treated as valid.  XML Schema section
  4.3.8.4 rejects only `minExclusive > maxExclusive`, even though equality
  gives an empty value space.
* `minExclusive == base maxInclusive` is treated as invalid.  XML Schema
  section 4.3.9.4 clause 2 contains a wording typo in the local copy:
  "greater the {value} of the parent maxInclusive".  The suite interprets this
  as `>=`, matching the surrounding empty-value-space prohibition pattern and
  processor behavior recorded for this project.

Some valid-restriction clauses are deliberately not covered because they cannot
be expressed using the built-in XML Schema base types available to Table
Constraints.  For example, no built-in type fixes `length`, `minLength`,
`maxLength`, `totalDigits`, `minExclusive`, `maxExclusive`, or
`enumerationValues` in the way needed to test every valid-restriction branch.

### Period canonicals: deferred restructure

The `canonical` column on `period` rows in `datatype-validity.csv` is currently
`self` for every Y row, including rows whose lexical is an abbreviated form
(e.g. `2024`, `2024Q1`, `2024-12-31`, `2024-01-01..2024-12-31`).  This is
structurally fine — the column's only hard requirement today is the
`datatypeValidityCanonicalFK` foreign-key constraint to `valuePK` — but it is
semantically incomplete: the natural canonical for a period value is its OIM
Common <<oc:period string representation#term-period-string-representation>>,
not the abbreviated lexical itself.

When the unique/reference key generator for `period` lands, it will need
canonicals to point to value_ids whose lexicals are the canonical period
string representation (e.g. `periodYear` should canonicalise to a value_id
with lexical `2024-01-01T00:00:00/2025-01-01T00:00:00`), so that all the
abbreviated, `..`-range and explicit-form rows referring to "all of 2024"
share the same canonical and thus the same equivalence class.  At that
point the canonical column will need to be revisited across all `period`
Y rows, and a number of new canonical-anchor value_ids added to
`values.csv` for the canonical forms that aren't yet present (most of the
abbreviated quarters/halves/weeks, and the negative-year and over-9999
variants).

Tracking this here so the future MR doesn't have to rediscover the
constraint.
