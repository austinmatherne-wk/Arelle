#!/bin/bash

OUTZIP=json-examples.zip

rm $OUTZIP

# extract all the hrefs from .md file which look like [link](href)
# provides extra \r which are ignored by zip

zip $OUTZIP README-examples.md `grep '\[.*\]' README-examples.md | sed 's/.*(\(.*\))./\1/'`
