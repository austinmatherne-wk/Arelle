# JSON Examples

### SMB loans table and metadata

This example produces seven facts for each firm's loans, dimensionalized by the
company's LEI, reporting CompanySize, an extensible enum (i.e. a QName) of micro/small/medium,
CountryOfIncorporation - string, ISO code, LimitGranted - monetary, PercentageCollateralisedAtInception,
InterestRateChargedAtInception, LoanStartDate and LoanMaturityDate (both dates)


[SMB Loans JSON data](loan-data.json)  

