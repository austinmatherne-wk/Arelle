# Open Information Model Conformance Suite

This directory contains conformance suites for the OIM specifications.

## Available suites

The available suites are:

* 100-json-conformant-processor - base suite for xBRL-JSON conformant processors.
* 200-json-validating-conformant-processor - additional tests for xBRL-JSON
  validating conformant processors.
* 300-csv-conformant-processor - suite for xBRL-CSV conformant processors.
* 400-csv-validating-conformant-processor - additional tests for xBRL-CSV
  validating conformant processors.
* 600-xml - suite for testing transformation of xBRL-XML documents.

## Test suite structure

Each directory contains an `index.xml` file containing a `<testcase>` element
with multiple `<variations>`.  An example variation is shown below:

```xml
<variation id="V-05" name="A simple instance with missing namespaces">
  <description>
    Simple instance missing the namespaces
  </description>
  <data>
    <instance readMeFirst="true">helloWorld-missing-prefixes-invalid.json</instance>
  </data>
  <result>
    <error>oimce:unboundPrefix</error>
  </result>
</variation>
```

Each variation has:

* an ID which is unique within the testcase
* a single input file, specified by the content of `variation/data/instance`.  The `readMeFirst` attribute has no meaning in these suites.
* a `<result>` element specifying the expected output of the variation, as
  described below.

## Expected results

The `<result>` element will contain one of the following:

* No elements.  The variation is a pass case, and a processor must raise no errors.
* One or more `<error>` elements, each containing an error code.  The variation
  is a fail case, and a processor must raise at least one of the specified
  error codes.  Processors may raise additional, unlisted errors.

Multiple error codes are provided where the error raised can reasonably depend
on the order in which a processor applies validation, although both the
specification and the conformance suite tests try to avoid this situation.

## Transformation outputs

At present, the suite tests only expected validation results.  This is expected
to change in future.  It is expected that processors will be expected to
produce xBRL-JSON instance documents which will be compared for OIM equivalence
with control files, although the exact process for this has not been defined.

## "invalidJSON" errors

xBRL-JSON and xBRL-CSV require `xbrlje:invalidJSON` and `xbrlce:invalidJSON`
(respectively) to be raised if the document being loaded is not a valid JSON
file.  This creates a problem for processors that support both specifications
and determine document type from the `documentType` property.  It is
recommended that processors implement an option to specify the expected
document type when running the conformance suites, so that the relevant error
can be raised.  For the purposes of XBRL Software Certification testing, these
errors will be treated as equivalent.

See https://gitlab.xbrl.org/oim/oim/-/issues/549
