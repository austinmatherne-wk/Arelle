# xBRL-CSV Examples

This package contains some simple examples to demonstrate the usage of the
xBRL-CSV specification.

The sample demonstrates a simple CSV data table representing information
about a set of loans.  For each loan, seven facts are reported,
dimensionalized by the company's LEI.  The facts report:

* CompanySize, an extensible enumeration (i.e. a QName) of micro/small/medium,
* CountryOfIncorporation - string, ISO code
* LimitGranted - monetary
* PercentageCollateralisedAtInception - numeric 
* InterestRateChargedAtInception - numeric
* LoanStartDate (date)
* LoanMaturityDate (date)

Sample [CSV data](loan-data-facts.csv) is provided, and the accompanying
[JSON Metadata](loan-data-metadata.json) defines the mapping into a set
of XBRL facts.
