iXBRL v1.1 Conformance Suite
============================

This conformance suite can be used to check a processor for conformance with
the Inline XBRL v1.1 specification.

Each test case consists of a single Inline XBRL document (.html), or a set of
Inline XBRL documents forming an Document Set.  These are identified in the
<data> element of the control file, e.g.:

    <data>
      <instance readMeFirst="true">FAIL-nonNumeric-any-ix-attribute.html</instance>
    </data>

Where multiple <instance> elements are present, the documents should be
consumed as a Document Set.

The expected result of each test can is defined by the <result> element in the
control file.  An invalid test case will have a value of "invalid" for the
"expected" attribute, e.g.:

    <result expected="invalid" nonStandardErrorCodes="true">
      <error>xbrl.core.xml.SchemaValidationError.cvc-complex-type_3_2_2</error>
      <error>xbrl.core.xml.SchemaValidationError.cvc-complex-type_3_2_2</error>
    </result>

The Inline XBRL specification does not define standard error codes, and so
processors are only required to correctly identify such cases as "invalid", and
are not required to produce the listed error codes.

A valid test case will list one or more XBRL instance files, which are the
expected outputs:

    <result expected="valid">
      <instance>PASS-nonNumeric-ix-format-attr-expanded-name-match.predictedOutput.xml</instance>
    </result>

A conformant processor must produce an XBRL instance that can be shown to be
equivalent to the expected output file.  The exact process by which this
comparison is done is not defined, but implementers are recommended to do the
comparison with reference to the XBRL Open Information Model.

An index to all test cases can be found in the "index.xml" file at the top
level of the conformance suite distribution.  Additionally, each directory of
tests contains its own index.xml file which can be used to run just the tests
in that directory.

XBRL validity
-------------

It is not required to validate the outputs for conformance with the XBRL v2.1
and XBRL Dimensions specifications, but processors are free to do so.  

Taxonomy Package
----------------

Most test cases use relative references to taxonomies in the "schemas"
directory.  A small number of tests use absolute URLs.  The XBRL Taxonomy
Package (www.example.com.zip) in the schemas directory can be used to configure
a processor with a DTS for the necessary absolute URLs.
