# Report Package Conformance Suite

This package provides a set a tests for checking the conformance of an XBRL
Report Package processor.

## Test suite structure

The test suite is defined by index.csv, which has the following fields:

* `input` - the name of the package file to test
* `errors` - a space-separated list of expected error codes
* `report_count` - a non-negative integer indicating the number of reports expected
* `description` - a text field explaining the purpose of the test

If the `errors` list is empty, the variation is a pass case, and
processors must not raise any errors.

If the `errors` list is non-empty, the variation is a fail case, and a
processor must raise at least one of the specified error codes.  Processors may
raise additional errors.

The error code prefixes used are defined in the Report Packages spec (rpe report package
errors; tpe for taxonomy package errors).

## Variation numbering

Varitions are grouped as follows:

* 0xx - basic zip structure and package identification tests
* 1xx - structural JSON constraints for reportPackage.json
* 2xx - co-constraints on documentType and package file extension
* 3xx - valid .xbri packages 
* 4xx - invalid .xbri packages 
* 5xx - valid .xbr packages 
* 6xx - invalid .xbr packages 
* 7xx - valid .zip packages 
* 8xx - invalid .zip packages 
* 9xx - future report packages
