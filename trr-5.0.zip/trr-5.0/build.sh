#!/bin/bash

../spec/common/bin/s4s-builder.sh $@
