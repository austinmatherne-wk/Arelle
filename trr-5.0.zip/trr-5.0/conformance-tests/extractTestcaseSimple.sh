#!/bin/bash
java -jar ${SAXON:-../../../infrastructure/s4s/common/bin/saxon9.jar} tests.xml extractTestcase.xsl  > testcase.xml
