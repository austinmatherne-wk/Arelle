import java.io.FileOutputStream

repositories {
    mavenCentral()
}

plugins {
    `java-library`
}

dependencies {
    runtimeOnly("net.sf.saxon:Saxon-HE:9.9.1-5")
}

fun getenv(name: String): String {
  val value = System.getenv(name)
  if (value == null) {
    throw IllegalStateException("Environment variable $name must be specified")
  }
  else {
    return value
  }
}

tasks {
  task<JavaExec>("transform") {
    main = "net.sf.saxon.Transform"
    classpath = sourceSets["main"].runtimeClasspath
    standardOutput = FileOutputStream(getenv("TRANSFORM_XML_OUTPUT"))
    args(listOf(getenv("TRANSFORM_XML_INPUT"), getenv("TRANSFORM_XML_STYLESHEET")))
  }
}
