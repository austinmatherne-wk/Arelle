#!/bin/bash
export TRANSFORM_XML_INPUT=tests.xml
export TRANSFORM_XML_STYLESHEET=extractTestcase.xsl
export TRANSFORM_XML_OUTPUT=testcase.xml
./gradlew transform
