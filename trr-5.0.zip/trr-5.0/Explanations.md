# TR4 notes

I have been asked to write a short document detailing my thoughts about TR4 and how I made the decisions I did, so as to avoid future people having to work out what I did what I did.

## New Transforms

### Languages

I have been sent by David Bell a spreadsheet, which is also in svn.xbrl, detailing the various languages required. I thus implemented transforms for the following languages:

* Bulgarian
* Croatian
* Czech
* Dutch
* Estonian
* Finnish
* French
* German
* Greek
* Hungarian
* Italian
* Latvian
* Lithuanian
* Norwegian
* Polish
* Portuguese
* Romanian
* Slovak
* Slovene
* Spanish
* Swedish

It might be helpful to note the languages that have not been implemented:

* Non-European languages such as Arabic and Chinese were not considered.
* Non-EU/EFTA languages, such as Turkish, Ukrainian and Serbian, and particularly notably Russian, which is a minority language in the Baltic countries and other parts of Eastern Europe.
* Irish, Maltese and Icelandic, for which I was informed there is no requirement as filers in Ireland, Malta and Iceland can file in other languages.
* Minority languages such as Welsh and Catalan.
* Dialects, most notably Austrian German, which has a different word for 'January' were not given their own transforms.
  The alternative Austrian German translation was made possible within the German transforms.
* English and Danish have pre-existing transforms

Looking at various sources, I saw a number of suggestions that use of Roman numerals for months (eg. 10 I 2019) is moderately common in some eastern European countries and archaic in central Europe.

### Formats

For each language, I created one transform to each of xs:gMonthDay, xs:date and xs:gYearMonth.
[I found that the Wikipedia page on 'date format by country' was very helpful](https://en.wikipedia.org/wiki/Date_format_by_country), and I also checked this using Google Translate.
From these sources, I deduced that most languages would use a 'DMY' format (ie. 10th January 2019) with 'DM' and 'MY' formats (10th January and January 2019) for the other data types.
The exceptions to this are Hungarian and Lithuanian, which use a 'YMD' format (2019. január 10., 2019. január and január 10) and Latvian, which uses 'YDM' (2019. gada 10. janvāris, 2019. gada janvāris and 10. janvāris).
Each language has one transform for each data type, though there is no reason that additional transforms could not be added to support additional formats if required.

### Schema and Regular Expressions

In creating the regular expressions that dates need to follow, I usually followed the approach taken by the Danish transforms.
These are very permissive, and thus could be used for abbreviations (10. jan 2019) or full month names (10. januar 2019).
However, there were a number of cases where I needed to deviate from this approach, usually by offering multiple possible strings for a month.
I aimed to permit all the months stated in the aforementioned spreadsheet and the months provided by Java's DateFormatSymbols, including the abbreviations.

Multiple strings for a month were necessitated by the following situations:

* Month names with diacritics (eg. février in French) are permitted with and without their diacritics (hence fevr and févr are permitted in the regex)
* For each language, the month is provided in lower case (jan), upper case (JAN) and sentence case (Jan).
  It appears that the grammatical requirement for months to be written with a capital letter (eg. January) is unusual to English and German, though I permitted lower case in German in order to follow the principle of being permissive.
* In some languages, the common abbreviation for the month is not a substring of the month name.
  Of particular note in this case is Lithuanian, where both 'rgp' and 'rugp' are acceptable cases for 'rugpjūtis' (August) and 'rgs' and 'rugs' are acceptable cases for 'rugsėjis' (September).
* I encountered a few Greek cases where a capital Latin script 'I' was used in place of a captial Greek alphabet iota.
  Both characters are thus permitted in the Greek transforms for the upper case letters only.
  It is worth noting that I did not see any similar cases in Bulgarian, which is the other language that doesn't use a Latin script.
  
In the Danish transforms, the identifier for the month does not need to be at the start of the word, merely that there is at least one non-numeric character after the date.
Thus, '10hijano2019' would be recognised as '2019-01-10'. 
However, in Finnish, Polish and Lithuanian, the standard abbreviations of the month cannot be used to uniquely identify the month in this way.
For example, in Finnish, the string 'lok' (October) also appears in 'elokuu' (August).
Consequently, the transforms for these three languages require that there is at least one non-alphanumeric character before the month identifier.

The Czech language poses a particular difficultly, since the presence of the string 'červen' (June) is not enough to identify the month since 'červenec' (July) is also in the Czech calendar.
Consequently, the Czech transforms are very prescriptive, requiring that the month identifier is always surrounded by a non-alphanumeric character on each side.
It is worth noting also that in the Czech language, the ending of the name of the month can change depending on its grammatical context, in a similar manner to Latin or Greek.
Thus, 'January 2019' would use the nominative case and translate to 'Leden 2019', but '10 January 2019' would use the genitive case and translate to '10. ledna 2019'.
Thus, the date-day-month-year-cs and date-day-month-cs only permit the accusative case and common abbreviations, whilst the date-month-year-cs transform permits the accusative, locative and nominative cases and common abbreviations.

It is my understanding that it was the original intention for the Danish transforms to be applicable to both Danish and Swedish dates, and thus the new Swedish transforms use the pre-existing Danish data types.

### Conformance tests

I have written conformance tests which are based on the existing Danish tests, except for the tests for the Czech transforms, which are based on the tests for the English transforms.

### Other notes

The new transforms have all been named using the the ISO 639 code for their language.
I followed the precedent set by the 'en' (English) transforms, which use the language code rather than a country code.

## Renamings

All the existing transforms have been renamed from using concatenated lower case (eg. datedaymonthyear) to using kebab case (eg. date-day-month-year), so that they are easier to read.
The corresponding data types were renamed to use a camel case version of the transform name, suffixed with 'Type'.

For the non-date transforms, the constant transforms (those that always transform to the same value) have been given the prefix 'fixed-', whilst the remaining numeric were simply converted to kebab case.

Date transforms always begin with 'date-'.
The existing dk and in transforms were renamed to use the ISO 639 language codes da and hi respectively.
The transforms that use a calendar other than the Gregorian calendar have been noted towards the begin.
The only current cases are country specific (Indian National and Japanese Regnal), so the ISO 3166-1 alpha-3 codes were used (ind and jpn respectively) to ensure that they are not confused with languages.
This means that only transforms with months written out in a specific language need a regional or language identifier on the end.
To ensure it is easier to identify when the month should be spelled out in a language and when it is numeric, the component of the transform that refers to the month is different between these two cases: 'monthname' or 'month' respectively.

I have added a non-normative table to the appendices of the specification to show the equivalent transform between TR3 and TR4.

## Changes to existing transforms

* fixed-zero (formerly zerodash) now permits any string as an input, in a similar manner to fixed-true, fixed-false and fixed-empty.
* num-dot-decimal, num-comma-decimal and num-unit-decimal are now much more liberal as to where digit separators are permitted, with spaces now allowed in the fractional part and the integer part being optional if the fractional part is present.
 * This means that the TR3 transforms numdotdecimalin and numunitdecimalin are now superfluous and have been removed
 * numunitdecimalin in TR3 did permit inputs such as '10.5' (transformed to 10.05), which is not permitted by num-unit-decimal in TR4.
   I consider this to be an unintended edge case.
   Similar cases with two digts in the fractional part will be supported with the same output when num-dot-decimal or num-comma-decimal are used.
* date-year-month-day now permits additional non-numeric characters after the day, which means that dateyearmonthdaycjk is now superfluous, so it has been removed.
* dateyearmonthcjk has been replaced by the more permissive date-year-month.
* date-day-month-year and date-day-month now accept Devanagari numerals.
 * This means that numeric dates that use Devanagari numerals (eg. 28०03०2019) are no longer supported.
   I consider this to be an unintended edge case.
* In TR3, datedaymonthyearin accepted numeric months, but for consistency, date-day-monthname-year-hi in TR4 only accepts months in Hindi.
  date-day-month-year will accept the numeric inputs.

## Useful references

* https://en.wikipedia.org/wiki/Date_format_by_country
* https://translate.google.co.uk/
* https://www.omniglot.com/language/time/months.htm


